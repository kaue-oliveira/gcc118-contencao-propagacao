# Piloto exploratório da etapa 2

Este lote inicial foi preservado para manter a rastreabilidade da revisão metodológica. A configuração efetivamente executada está dentro de `execucao.json`. Não é o lote principal da entrega.

A revisão identificou comparações de origens sem c=3 e orçamentos altos sem regra de seleção sistemática. A grade principal em `experimentos/etapa-2.json` corrige esses pontos; sua execução integral fica em `resultados/etapa-2/`.

As conclusões, tabelas e gráficos do relatório principal usam somente o lote revisado. Não se escolhe o melhor tempo entre piloto e execução principal. A justificativa completa está em `docs/relatorios/desenho-experimental-etapa-2.md`.

Os registros de testes e hashes deste diretório descrevem o estado do piloto, anterior à atualização da grade e do teste que confere seu tamanho. O verificador atual foi destinado à grade principal.
